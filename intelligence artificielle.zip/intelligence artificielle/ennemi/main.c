/**
* @file main.c
* @brief Testing Program.
* @author yosra mekaoui
* @version 0.1
* @date may 02, 2020
*
* Testing program for animation (deplacement aleatoire)
*
*/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "ennemi.h"

int main()
{
	SDL_Surface *ecran;

	Ennemi e;
	bool boucle=true;

	SDL_Event event;

	SDL_Surface *player;
	player=IMG_Load("persoo.png");

	SDL_Surface *background;
	background=IMG_Load("arrierePlan.png");
	SDL_Rect position={400,400};//initialisit l'ecran f 200 400

	SDL_Rect pos_player={0,400};

	Initialisation_Ennemi(&e,position);
	bool Game;
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		fprintf(stderr, "Erreur.\n");
		return 1;
	}
	
	ecran = SDL_SetVideoMode(1000, 800, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);//configuration de l'ecran (hatina longeur w largeur de l'ecran)

	while(boucle)
	{
		SDL_BlitSurface(background,NULL,ecran,NULL);//coller l'image sur l'ecran
		SDL_BlitSurface(player,NULL,ecran,&pos_player);
		Affichage_Ennemi(&e,ecran);
		SDL_Flip(ecran);//mise a jour de l'ecran
		//Animation_Ennemi(&e,ecran);
		AI_Ennemy(&e,pos_player);

		SDL_EnableKeyRepeat(5,5);
		SDL_PollEvent(&event);

		switch (event.type)
		{ 
			case SDL_KEYDOWN:
			{
				if(event.key.keysym.sym==SDLK_RIGHT)
				{
					pos_player.x+=10;
				}
				if(event.key.keysym.sym==SDLK_LEFT)
				{
					pos_player.x-=10;
				}
				if(event.key.keysym.sym==SDLK_UP)
				{
					pos_player.y-=10;
				}
				if(event.key.keysym.sym==SDLK_DOWN)
				{
					pos_player.y+=10;
				}
				break;
			}
		}

	}
	Free_Ennemi(&e);// on libere la memoire
	SDL_Quit();//et on quitte
	exit(0);
	return EXIT_SUCCESS;
	return 0;
}
