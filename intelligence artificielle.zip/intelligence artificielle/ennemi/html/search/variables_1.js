var searchData=
[
  ['direction',['Direction',['../structEnnemi.html#a3b56bcbc233f62ad106862a75118081d',1,'Ennemi']]],
  ['distance_5fai',['Distance_AI',['../structEnnemi.html#a56187d2c3c0b4647886f088a0c8fbb2f',1,'Ennemi']]]
];
