#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "ennemi.h"

int main()
{
	SDL_Surface *ecran;

	Ennemi e;
	bool boucle=true;

	SDL_Surface *background;
	background=IMG_Load("arrierePlan.png");
	SDL_Rect position={200,400};

	Initialisation_Ennemi(&e,position);
	bool Game;
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		fprintf(stderr, "Erreur.\n");
		return 1;
	}
	
	ecran = SDL_SetVideoMode(1000, 800, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);

	while(boucle)
	{
		SDL_BlitSurface(background,NULL,ecran,NULL);
		SDL_Flip(ecran);
		Animation_Ennemi(&e,ecran);
	}
	Free_Ennemi(&e);
	SDL_Quit();
	exit(0);
	return EXIT_SUCCESS;
	return 0;
}