/** 
   * @file main.c 
*/
#include "dep.h"

int main(int argc, char **argv)
{
    int continuer = 1, press = 0, running = 1, choice = 0, choice2 = 0, choice3 = 4, choice4 = 7, running2 = 1, run = 1, run2 = 1;
    SDL_Surface *ecran = NULL, *zozor = NULL, *sapin;
    SDL_Rect positionZozor, positinsapin;
    SDL_Event event;
    Objet perso, tab[20], tab2[3];
    initialiser(&perso, tab, tab2);

    SDL_Init(SDL_INIT_VIDEO);

    ecran = SDL_SetVideoMode(600, 500, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);

    SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 255, 255, 255));
    SDL_WM_SetCaption("deplacement perso", NULL);

    //SDL_BlitSurface(perso.img, NULL, ecran, &perso.pos);

    SDL_EnableKeyRepeat(100, 100);

    while (running)
    {
        while (run)
        {
            SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 255, 255, 255));
            SDL_BlitSurface(tab[choice3].img, NULL, ecran, &tab[choice3].pos);
            SDL_Flip(ecran);
            SDL_WaitEvent(&event);
            switch (event.type)
            {
            case SDL_QUIT:
                run = 0;
                run2 = 0;
                running = 0;
                running2 = 0;
                continuer = 0;
                break;
            case SDL_KEYDOWN:
                switch (event.key.keysym.sym)
                {

                case SDLK_DOWN:
                    choice3++;
                    if (choice3 > 6)
                        choice3 = 5;

                    break;
                case SDLK_UP:
                    choice3--;
                    if (choice3 < 5)
                        choice3 = 6;

                    break;
                case SDLK_RETURN:
                    if (choice3 < 7 && choice3 > 4)
                    {
                        if (choice3 == 6)
                        {

                            FILE *f = fopen("save_file", "r");
                            fscanf(f, "%hd %hd %d %d", &(perso.pos.x), &(perso.pos.y), &choice, &choice2);
                            fclose(f);


                            running = 0;
                            running2 = 0;
                        }
                        run = 0;
                    }

                    break;
                }
                break;
            }
        }
        if (choice3 == 5)
        {

            SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 255, 255, 255));
            SDL_BlitSurface(tab[choice].img, NULL, ecran, &tab[choice].pos);
            SDL_Flip(ecran);
            SDL_WaitEvent(&event);
            switch (event.type)
            {
            case SDL_QUIT:
                running = 0;
                running2 = 0;
                continuer = 0;
                break;
            case SDL_KEYDOWN:
                switch (event.key.keysym.sym)
                {

                case SDLK_RIGHT:
                    choice++;
                    if (choice > 3)
                        choice = 1;

                    break;
                case SDLK_LEFT:
                    choice--;
                    if (choice < 1)
                        choice = 3;

                    break;
                case SDLK_RETURN:
                    if (choice < 4 && choice > 0)
                    {
                        running = 0;
                        printf("%d", choice);
                    }

                    break;
                }
                break;
            }
        }
    }
    while (running2)
    {
        SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 255, 255, 255));
        SDL_BlitSurface(tab2[choice2].img, NULL, ecran, &tab2[choice2].pos);
        SDL_Flip(ecran);
        SDL_WaitEvent(&event);
        switch (event.type)
        {
        case SDL_QUIT:
            running = 0;
            running2 = 0;
            continuer = 0;
            break;
        case SDL_KEYDOWN:
            switch (event.key.keysym.sym)
            {

            case SDLK_RIGHT:
                choice2++;
                if (choice2 > 2)
                    choice2 = 1;

                break;
            case SDLK_LEFT:
                choice2--;
                if (choice2 < 1)
                    choice2 = 2;

                break;
            case SDLK_RETURN:
                if (choice2 < 3 && choice2 > 0)
                {
                    running2 = 0;

                    SDL_EnableKeyRepeat(10, 10);
                }

                break;
            }
            break;
        }
    }
    if (choice < 4 && choice > 0)
    {
                SDL_EnableKeyRepeat(10, 10);
        if (choice2 == 1)
            perso.img = IMG_Load("per1.png");
        else
            perso.img = IMG_Load("per2.png");

            SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 255, 255, 255));
        while (continuer)
        {
            
            SDL_WaitEvent(&event);
            switch (event.type)
            {
            case SDL_QUIT:
                SDL_EnableKeyRepeat(100, 100);
                while (run2)
                {
                    SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 255, 255, 255));
                    SDL_BlitSurface(tab[choice4].img, NULL, ecran, &tab[choice4].pos);
                    SDL_Flip(ecran);
                    SDL_WaitEvent(&event);
                    switch (event.type)
                    {

                    case SDL_KEYDOWN:
                        switch (event.key.keysym.sym)
                        {

                        case SDLK_RIGHT:
                            choice4++;
                            if (choice4 > 9)
                                choice4 = 8;

                            break;
                        case SDLK_LEFT:
                            choice4--;
                            if (choice4 < 8)
                                choice4 = 9;

                            break;
                        case SDLK_RETURN:
                            if (choice4 < 10 && choice4 > 7)
                            {
                                if (choice4 == 8)
                                {
                                    FILE *f = fopen("save_file", "w");
                                    fprintf(f, "%hd %hd %d %d \n", perso.pos.x, perso.pos.y, choice, choice2);

                                    fclose(f);
                                }
                                return 0;
                                /*                                 run2 = 0;
                                continuer = 0; */
                            }

                            break;
                        }
                        break;
                    }
                }

                break;
            case SDL_KEYDOWN:
                switch (event.key.keysym.sym)
                {
                case SDLK_UP: // Flèche haut
                    if (choice == 1)
                    {
                        perso.pos.y -= 2;
                    }

                    break;
                case SDLK_DOWN: // Flèche bas
                    if (choice == 1)
                        perso.pos.y += 2;
                    break;
                case SDLK_RIGHT: // Flèche droite
                    if (choice == 1)
                        perso.pos.x += 2;
                    break;
                case SDLK_LEFT: // Flèche gauche2
                    if (choice == 1)
                        perso.pos.x -= 2;
                    break;
                }
                break;

            case SDL_MOUSEBUTTONDOWN:
                if (choice == 3)
                {
                    if (event.button.button == SDL_BUTTON_LEFT)
                    {

                        if (event.button.x <= ecran->w / 2)

                            perso.pos.x -= 20;
                        else
                            perso.pos.x += 20;
                    }
                }

                break;
            }

            SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 255, 255, 255));
            SDL_BlitSurface(perso.img, NULL, ecran, &perso.pos);

            SDL_Flip(ecran);
        }
    }

    SDL_FreeSurface(perso.img);
    SDL_Quit();
    return 0;
}
