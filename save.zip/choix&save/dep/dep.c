
/** 
   * @file dep.c 
*/

#include "dep.h"

/**
* @brief To initialize the objecs.
* @param perso character 
* @param tab the array of the images for menu
* @param tab2 the array of the images for characters
* @return Nothing
*/
 void initialiser (Objet *perso,Objet tab[] ,Objet tab2[] ) 
 {
  perso->img=IMG_Load("per1.png") ;
  perso->pos.x=0 ;
  perso->pos.y=0 ;
  
  tab[0].img=IMG_Load("Choose.png") ;
  tab[0].pos.x=0 ;
  tab[0].pos.y=70 ;
  
  tab[1].img=IMG_Load("Clavier.png") ;
  tab[1].pos.x=0 ;
  tab[1].pos.y=70 ;
  
  tab[2].img=IMG_Load("Manette.png") ;
  tab[2].pos.x=0 ;
  tab[2].pos.y=70 ;
  
  tab[3].img=IMG_Load("Souris.png") ;
  tab[3].pos.x=0 ;
  tab[3].pos.y=70 ;
  
  tab[4].img=IMG_Load("save/menu1.png") ;
  tab[4].pos.x=40 ;
  tab[4].pos.y=0 ;
  
  tab[5].img=IMG_Load("save/newgame.png") ;
  tab[5].pos.x=40 ;
  tab[5].pos.y=0 ;
  
  tab[6].img=IMG_Load("save/loadgame.png") ;
  tab[6].pos.x=40 ;
  tab[6].pos.y=0 ;
  
  tab[7].img=IMG_Load("save/quit.png") ;
  tab[7].pos.x=40 ;
  tab[7].pos.y=0 ;
  
  tab[8].img=IMG_Load("save/yes.png") ;
  tab[8].pos.x=40 ;
  tab[8].pos.y=0 ;
  
  tab[9].img=IMG_Load("save/no.png") ;
  tab[9].pos.x=40 ;
  tab[9].pos.y=0 ;

  tab2[0].img=IMG_Load("choose2.png") ;
  tab2[0].pos.x=0 ;
  tab2[0].pos.y=70 ;
  
  tab2[1].img=IMG_Load("perso1.png") ;
  tab2[1].pos.x=0 ;
  tab2[1].pos.y=70 ;
  
  tab2[2].img=IMG_Load("perso2.png") ;
  tab2[2].pos.x=0 ;
  tab2[2].pos.y=70 ;
  
 }

